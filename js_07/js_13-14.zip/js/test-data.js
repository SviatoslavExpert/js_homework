var test = [
        {
          text: 'Вопрос 1',
          answers: [
            {
              text: 'Ответ 1'
              ,correct: true
            },
            {
              text: 'Ответ 2'
              ,correct: false
            },
            {
              text: 'Ответ 3'
              ,correct: true
            },
          ]
        },
        {
          text: 'Вопрос 2',
          answers: [
            {
              text: 'Ответ 1'
              ,correct: false
            },
            {
              text: 'Ответ 2'
              ,correct: false
            },
            {
              text: 'Ответ 3'
              ,correct: true
            },
          ]
        }
      ];